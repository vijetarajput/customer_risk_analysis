

# Master Project: Risk Analysis & Predictive Modeling
# Phase 2 - SQL Analysis Queries

create database risk_analysis;
use risk_analysis;

select COUNT(*) AS total_rows from master_dataset;

select * from master_dataset LIMIT 10;

-- 1. Risk segmentation by region & employment
select region, employment_status,
       COUNT(*) AS total_customers,
       AVG(risk_score) AS avg_risk
from master_dataset
group by region, employment_status
order by avg_risk DESC;

-- 2. Average loan amount by credit risk category
select credit_risk_category, avg(loan_amount) AS avg_loan
from master_dataset
group by credit_risk_category
order by avg_loan DESC;

-- 3. Default rate by claim type & employment status
select claim_type, employment_status,
       avg(CASE When default_history = TRUE Then 1 ELSE 0 End) AS default_rate
from master_dataset
group by claim_type, employment_status
order by default_rate DESC;

-- 4. Claim status outcomes for high-risk individuals
select claim_status, COUNT(*) AS total_claims
from master_dataset
where credit_risk_category = 'High Risk'
group by claim_status
order by total_claims DESC;

-- 5. Average credit score per region

select region, AVG(credit_score) AS avg_credit_score
from master_dataset
group by region
order by avg_credit_score DESC;

-- 6. Average DTI ratio by employment status
select employment_status, AVG(debt_to_income_ratio) AS avg_dti
from master_dataset
group by employment_status
order by avg_dti DESC;

-- 7. Count of customers per DTI category
select dti_category, COUNT(*) AS total_customers
from master_dataset
group by dti_category
order by total_customers DESC;

-- 8. Default rate by credit risk category
select credit_risk_category,
       avg(case WHEN default_history = TRUE then 1 ELSE 0 end) AS default_rate
from master_dataset
group by credit_risk_category
order by default_rate DESC;

-- 9. Claim approval rate by region
select region,
       avg(case WHEN claim_status='Approved' then 1 ELSE 0 END) AS approval_rate
from master_dataset
group by region
order by approval_rate DESC;

-- 10. Claims per month (time-series)
select DATE_FORMAT(incident_date,'%Y-%m') AS month,
       claim_type,
       COUNT(*) AS total_claims
from master_dataset
group by month, claim_type
order by month ASC, claim_type;
